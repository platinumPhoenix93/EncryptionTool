package com.encryptiontool.Ciphers;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Abstract class extends abstract cipher class
 * Used for cipher types that rely on shifting values (Vigenere, Caesar)
 * Contains methods for shifting character values and preparing text for encryption
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public abstract class ShiftCipher extends Cipher {

    ArrayList<Character> encryptionTextArray = new ArrayList<>();


    /**
     * Shifts the value of a character by the value of a key (Uses ascii value of the character)
     *
     * @param key      value for shift
     * @param position position of character to shift
     */
    void shiftValue(int key, int position) {
        int temp;
        temp = encryptionTextArray.get(position) + key;
        if (temp > 90) { //If the value of the shifted character is not within the ASCII range of upper case alphabetic characters
            resultText.append((char) (temp - 26)); //Loop back to the start of the alphabet
        } else if (temp < 65) { //If the value of the shifted character is below the range of upper case alphabetic characters (this method is also used for decryption)
            resultText.append((char) (temp + 26)); //Loop back to the end of the alphabet
        } else {
            resultText.append((char) temp);
        }
    }

    /**
     * Loads the desired encryption text from a file, and forms an array of characters stripped of non alphabetic characters
     *
     * @param filename name of the file to load text from
     * @throws IOException If unable to load file
     */
    void loadAndPrepareText(String filename) throws IOException {

        loadEncryptionText(filename);
        stripNonAlphabeticChars();
    }

    /**
     * Prepares the plain text as with getEncryptText method, but also converts it from an array of characters to a stringbuilder, and returns a string
     *
     * @param filename name of the file to load text from
     * @return prepared plain text - stripped of all non-alphabetic characters and converted to upper case
     * @throws IOException If unable to load file
     */
    public String preparePlainText(String filename) throws IOException {
        loadAndPrepareText(filename);
        StringBuilder plainText = new StringBuilder();

        for (Character c : encryptionTextArray) { //Convert from array of chars to stringBuilder
            plainText.append(c);
        }

        return plainText.toString();
    }

    /**
     * Strips non alphabetic character from a string
     */

    void stripNonAlphabeticChars() {
        char[] tempArray = new char[encryptionText.length()]; //Create array of chars length of string
        encryptionText.getChars(0, encryptionText.length(), tempArray, 0); //Get chars from string and populate array with them
        for (char c : tempArray) { //Check if each character in the array is alphabetic and add to separate array if it is
            if (Character.isAlphabetic(c)) {
                encryptionTextArray.add(c);
            }
        }
    }

}
