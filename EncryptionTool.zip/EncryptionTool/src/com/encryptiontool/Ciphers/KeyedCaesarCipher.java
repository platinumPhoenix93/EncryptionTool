package com.encryptiontool.Ciphers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Keyed Caesar Cipher class
 * Contains methods for encrypting and decrypting text
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public class KeyedCaesarCipher extends Cipher {

    private ArrayList<Character> tempAlphabet = new ArrayList<>();
    private ArrayList<Character> keyedAlphabet = new ArrayList<>();
    private final ArrayList<Character> ALPHABET = new ArrayList<>(Arrays.asList('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'));

    /**
     * Basic constructor for KeyedCaesarCipher object
     */

    public KeyedCaesarCipher() {
    }

    /**
     * Loads a file and key from given file names, and encrypts the text with the key value
     *
     * @param encryptionTextFilename file to load text to encrypt from
     * @param cipherKeyFilename      file to load key from
     * @return returns encrypted text as a String
     * @throws IOException if unable to load file
     */

    public String encrypt(String encryptionTextFilename, String cipherKeyFilename) throws IOException {
        loadKey(cipherKeyFilename);
        loadEncryptionText(encryptionTextFilename);
        buildKeyedAlphabet();
        shiftCharacters();
        return resultText.toString();
    }

    /**
     * Loads a file and key from given file name, and decrypts the text by reversing the key
     *
     * @param decryptionTextFileName file to load text to decrypt from
     * @param cipherKeyFilename      file to load key from
     * @return returns decrypted text as a String
     * @throws IOException if unable to load file
     */
    public String decrypt(String decryptionTextFileName, String cipherKeyFilename) throws IOException {
        loadKey(cipherKeyFilename);
        loadEncryptionText(decryptionTextFileName);
        buildKeyedAlphabet();
        unShiftCharacters();
        return resultText.toString();
    }

    /**
     * Reverses the shift of characters using the key. Enables the encrypted text to be mapped onto the alphabet for decryption
     */
    private void unShiftCharacters() {
        char[] encryptionTextArray = new char[encryptionText.length()]; //Convert text to array of chars
        encryptionText.getChars(0, encryptionText.length(), encryptionTextArray, 0);
        int pos;

        for (Character c : encryptionTextArray) { //Loop through array
            if (Character.isAlphabetic(c)) {
                pos = keyedAlphabet.indexOf(c); //Find the position of the character in the keyed alphabet
                //Append value of the character at pos in the unkeyed alphabet onto a stringBuilder for the resulting text
                resultText.append(ALPHABET.get(pos));
            }
        }
    }

    /**
     * Shifts the characters using the key. Maps characters from the alphabet onto an adjusted keyed alphabet
     */
    private void shiftCharacters() {
        char[] encryptionTextArray = new char[encryptionText.length()]; //Convert text to array of chars
        encryptionText.getChars(0, encryptionText.length(), encryptionTextArray, 0);
        int pos;

        for (Character c : encryptionTextArray) { //Loop through array
            if (Character.isAlphabetic(c)) {
                pos = ALPHABET.indexOf(c); //Find the position of the character in the unkeyed alphabet
                //Append value of the character at pos in the keyed alphabet onto a stringBuilder for the resulting text
                resultText.append(keyedAlphabet.get(pos));
            }
        }
    }

    /**
     * Finds all unique characters from the key text and adds them to a keyed alphabet arraylist of chars
     */

    private void findUniqueCharacters() {

        char[] keyArray = new char[key.length()];
        key.getChars(0, key.length(), keyArray, 0); //Convert key into an array of characters

        for (char t : keyArray) {
            if (!keyedAlphabet.contains(t) && Character.isAlphabetic(t)) { //Do not add character if they have already been added or if it is not alphabetic
                keyedAlphabet.add(t); //Build a new alphabet, with unique characters at the start
            }
        }
    }

    /**
     * Creates a copy of the alphabet into a temp alphabet array, and removes all characters that form the key from the temp alphabet.
     */
    private void removeKeyFromAlphabet() {
        tempAlphabet.addAll(ALPHABET);
        for (Character c : keyedAlphabet) {
            tempAlphabet.remove(c);
        }
    }

    /**
     * Build keyed alphabet by finding unique character, removing them from the alphabet, and placing them at the start of the keyed alphabet
     * Then appends alphabet with removed characters onto the end of the keyed alphabet
     */
    private void buildKeyedAlphabet() {
        findUniqueCharacters(); //Start keyed alphabet by adding all the unique character from the key to the array
        removeKeyFromAlphabet(); //Remove key characters from the alphabet
        keyedAlphabet.addAll(tempAlphabet); //Add alphabet with key characters removed to the end of the keyed alphabet
    }


}
