package com.encryptiontool.Ciphers;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Vigenere Cipher Class
 * Contains methods for encrypting and decrypting text using vigenere cipher
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public class VigenereShiftCipher extends ShiftCipher {

    private ArrayList<Integer> shifts = new ArrayList<>();

    /**
     * Basic constructor for VigenereShiftCipher class
     */
    public VigenereShiftCipher() {

    }

    /**
     * Loads a file and key from given file names, and encrypts the text using the key value
     *
     * @param encryptionTextFilename file to load text to encrypt from
     * @param cipherKeyFilename      file to load key from
     * @return returns encrypted text as a String
     * @throws IOException if unable to load file
     */
    public String encrypt(String encryptionTextFilename, String cipherKeyFilename) throws IOException {
        loadKey(cipherKeyFilename);
        generateKeyArray();
        loadAndPrepareText(encryptionTextFilename);
        shiftCharacters();
        return resultText.toString();
    }

    /**
     * Loads a file and key from given file names, and decrypts the text using the key value
     *
     * @param decryptionTextFilename file to load text to encrypt from
     * @param cipherKeyFilename      file to load key from
     * @return returns decrypted text as a String
     * @throws IOException if unable to load file
     */
    public String decrypt(String decryptionTextFilename, String cipherKeyFilename) throws IOException {
        loadKey(cipherKeyFilename);
        generateKeyArray();
        loadAndPrepareText(decryptionTextFilename);
        unShiftCharacters();
        return resultText.toString();
    }

    /**
     * Generates an array of ints, each int indicating how much of a shift should be applied
     */

    private void generateKeyArray() {
        char[] keyArray = new char[key.length()]; //Create new array of keys
        key.getChars(0, key.length(), keyArray, 0); //Populate array with chars from the key

        for (char c : keyArray) { //Loop through each char in the array
            if (Character.isAlphabetic(c)) {
                shifts.add(((int) c) - 65); //And replace the ASCII value of the key with the actual shift amount (uppercase alphabet starts at 65)
            }
        }
    }

    /**
     * Loops though the encryption text and performs the shiftCharacters method from the superclass, providing it the value
     * of the shifts array at shifts.get(i % shifts.size()) and i.
     * This causes the shift values to loop continuously for the length of the encryption text.
     */
    private void shiftCharacters() {
        for (int i = 0; i < encryptionTextArray.size(); i++) { //loop through encryption text
            super.shiftValue(shifts.get(i % shifts.size()), i); //Modulo is used with the size of the shifts array so it loops back to position 0 after it reaches the end
        }

    }

    /**
     * Loops though the encrypted text and performs the shiftCharacters method from the superclass, providing it the value
     * of the negative shifts array at shifts.get(i % shifts.size()) and i.
     * This causes the shift values to loop continuously for the length of the encryption text.
     */
    private void unShiftCharacters() {
        for (int i = 0; i < encryptionTextArray.size(); i++) {
            super.shiftValue(-(shifts.get(i % shifts.size())), i);
        }

    }
}

