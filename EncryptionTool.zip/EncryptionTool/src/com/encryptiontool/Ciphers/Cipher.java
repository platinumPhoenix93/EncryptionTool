package com.encryptiontool.Ciphers;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Abstract Cipher class, contains general methods for loading and changing keys, and loading text
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public abstract class Cipher {


    StringBuilder key = new StringBuilder();
    StringBuilder encryptionText = new StringBuilder();
    StringBuilder resultText = new StringBuilder();

    /**
     * Loads an encryption key from a specified filepath.
     *
     * @param filename name of the file to load
     * @return returns key as string. Used if user wishes to print the key.
     * @throws IOException If unable to load file
     */
    public String loadKey(String filename) throws IOException {
        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr);
             Scanner infile = new Scanner(br)) {
            while (infile.hasNext()) {
                key.append(infile.next().toUpperCase());
            }
        } catch (InputMismatchException ime) {
            System.err.println("Key is in incompatible format");
        }
        return key.toString();
    }

    /**
     * Enables the user to change a given encryption key
     *
     * @param filename name of the file to load
     * @param newKey   the key to replace the old key with
     */
    public void changeKey(String filename, String newKey) {
        try {
            PrintWriter writer = new PrintWriter(filename);
            writer.write(newKey);
            writer.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }

    }

    /**
     * Loads the text to encrypt from a given file
     *
     * @param filename name of the file which contains text to encrypt
     * @throws IOException            if unable to load file
     * @throws InputMismatchException if file contents are in an invalid format
     */

    void loadEncryptionText(String filename) throws IOException, InputMismatchException {
        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr);
             Scanner infile = new Scanner(br)) {
            while (infile.hasNext()) {
                encryptionText.append(infile.nextLine().toUpperCase());
            }
        } catch (InputMismatchException ime) {
            System.err.println("Input is in incorrect format");
        }
    }
}
