package com.encryptiontool.Ciphers;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Caesar Cipher Class
 * Contains methods for encrypting and decrypting text via caesar cipher
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public class CaesarShiftCipher extends ShiftCipher {

    int key = 0;

    /**
     * Basic constructor for CaesarShiftCipher object
     */

    public CaesarShiftCipher() {

    }

    /**
     * Loads a file and key from given file names, and encrypts the text with the key value (must be numeric between 1-25)
     *
     * @param encryptionTextFilename file to load text to encrypt from
     * @param cipherKeyFilename      file to load key from
     * @return returns encrypted text as a String
     * @throws IOException if unable to load file
     */

    public String encrypt(String encryptionTextFilename, String cipherKeyFilename) throws IOException {

        loadKey(cipherKeyFilename);
        loadAndPrepareText(encryptionTextFilename);
        shiftCharacters();
        return resultText.toString();

    }

    /**
     * Loads a file and a key from given file names, and decrypts the text with the key value (must be numeric between 1-25)
     *
     * @param encryptedTextFilename file to load text to decrypt from
     * @param cipherKeyFilename     file to load key from
     * @return returns decrypted text as a String
     * @throws IOException if unable to load file
     */

    public String decrypt(String encryptedTextFilename, String cipherKeyFilename) throws IOException {

        loadKey(cipherKeyFilename);
        loadAndPrepareText(encryptedTextFilename);
        unShiftCharacters();
        return resultText.toString();
    }

    /**
     * Shifts the values of each char in the encryption text by the key value. Calls shiftValues from ShiftCipher superclass
     * to enable character to loop back to the start of the alphabet if they fall outside the ASCII values allowable
     */
    private void shiftCharacters() {
        for (int i = 0; i < encryptionTextArray.size(); i++) {
            super.shiftValue(key, i);
        }
    }

    /**
     * Shifts the values of each char in the encrypted text by the negative of the key value. Calls shiftValues from ShiftCipher
     * superclass to enable character to loop back to the end of the alphabet if they fall outside of the ASCII values allowable
     */
    private void unShiftCharacters() {
        for (int i = 0; i < encryptionTextArray.size(); i++) {
            super.shiftValue(-key, i);
        }
    }


    /**
     * Overrides load key method from superclass, as this class requires an integer as its key.
     *
     * @param filename name of the file to load
     * @return key as string
     * @throws InputMismatchException If input is not an integer
     * @throws IOException            If unable to load file
     */
    @Override
    public String loadKey(String filename) throws InputMismatchException, IOException {
        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr);
             Scanner infile = new Scanner(br)) {

            key = infile.nextInt();
            return ((Integer) key).toString();
        }

    }
}

