package com.encryptiontool.GUI;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * Controller class for the Save file GUI window of the encrytion tool app
 * Handles inputs from elements on the GUI
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public class SaveOperationController {

    private String resultText;

    //Link variables with their counterparts on the "SaveOperationPopup.fxml" file
    FileChooser fc;
    @FXML
    Button saveFile;
    @FXML
    Button closePopup;


    /**
     * Allows for the transfer of text from another object
     *
     * @param text String to transfer to this object
     */
    public void transferText(String text) {
        resultText = text;
    }

    /**
     * Close the current stage
     */
    @FXML
    void closeSaveConfirmation() {
        Stage stage = (Stage) closePopup.getScene().getWindow();
        stage.close();
    }

    /**
     * Create a filechooser with a txt file filter, and open a window that allows the user to save the desired text to a txt file
     */
    public void saveResult() {
        File saveLocation;
        fc = new FileChooser();
        fc.setTitle("Save As");
        FileChooser.ExtensionFilter txtFilter = new FileChooser.ExtensionFilter(".txt files (*.txt)", "*.txt"); //txt filter - can only be saved as .txt file
        fc.getExtensionFilters().add(txtFilter); //add txt filter
        saveLocation = fc.showSaveDialog(new Stage()); //Open save filechooser, and save the result to saveLocation
        if (saveLocation != null) { //If user does not select 'cancel'
            saveResultToFile(saveLocation); //Save the file in the desired location with the given name
            closeSaveConfirmation(); //Close save popup
        }
    }

    /**
     * Saves a file with the desired name, and uses the string resultText to populate the file
     *
     * @param saveLocation location and name of the file
     */
    private void saveResultToFile(File saveLocation) {
        try {
            PrintWriter pw;
            pw = new PrintWriter(saveLocation);
            pw.println(resultText);
            pw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
