package com.encryptiontool.GUI;

import com.encryptiontool.Ciphers.CaesarShiftCipher;
import com.encryptiontool.Ciphers.KeyedCaesarCipher;
import com.encryptiontool.Ciphers.VigenereShiftCipher;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

/**
 * Controller class for the main GUI window of the encryption tool app
 * Handles inputs from elements on the GUI
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public class MainAppController {


    //Locations for the key files for each encryption type, must be in local folder of project
    private final String VIGENEREKEYFILE = "VigenereCipherKey.txt";
    private final String CAESARKEYFILE = "CaesarCipherKey.txt";
    private final String KEYEDCAESARKEYFILE = "KeyedCaesarCipherKey.txt";
    private String resultText;

    //Link variables with their counterparts on the "EncryptionToolGUI.fxml" file
    @FXML
    Label encryptTextLabel;
    @FXML
    Button confirmButton;
    @FXML
    ComboBox<String> selectionBox;
    @FXML
    RadioMenuItem keyCaesarRadio;
    @FXML
    RadioMenuItem caesarRadio;
    @FXML
    RadioMenuItem vigenereRadio;
    @FXML
    ToggleGroup encryptionType;
    @FXML
    TextField newKeyInput;
    @FXML
    Label promptText;
    @FXML
    Button exitButton;


    /**
     * Handles functionality in the event that the "confirmButton" button is pressed
     * confirmButton appears as a button with the text "Go!" on the GUI
     * Checks contents of the selectionBox, and responds appropriately.
     *
     * @throws IOException if unable to load file
     */
    public void confirmationPress() throws IOException {

        //Add radio menu buttons to ToggleGroup
        encryptionType = new ToggleGroup();
        keyCaesarRadio.setToggleGroup(encryptionType);
        caesarRadio.setToggleGroup(encryptionType);
        vigenereRadio.setToggleGroup(encryptionType);

        if (selectionBox.getValue() != null) {
            if (selectionBox.getValue().equals("Display Prepared Plain Text")) { //Same functionality regardless of encryption type
                printPlainText();
            } else if (selectionBox.getValue().equals("vc awaitingInput")) { //Unique flag value, not user selectable
                changeVigenereKey();
            } else if (selectionBox.getValue().equals("cc awaitingInput")) { //Unique flag value, not user selectable
                changeCaesarKey();
            } else if (selectionBox.getValue().equals("kc awaitingInput")) { //Unique flag value, not user selectable
                changeKeyedCaesarKey();
            } else if (encryptionType.getSelectedToggle().equals(caesarRadio)) {
                handleCaesarInput();
            } else if (encryptionType.getSelectedToggle().equals(keyCaesarRadio)) {
                handleKeyedCaesarInput();
            } else if (encryptionType.getSelectedToggle().equals(vigenereRadio)) {
                handleVignereInput();
            }
        }
    }

    /**
     * Changes the scene by hiding the selection box, unhiding a text input box, and changing the prompt text on screen to
     * indicate to the user what they should do
     */
    private void switchToKeyInputScene() {
        newKeyInput.setVisible(true);
        selectionBox.setVisible(false);
        promptText.setText("Enter new Key: ");
    }

    /**
     * Changes from key input scene back to the default scene that is present upon loading the tool
     */

    private void switchToDefaultScene() {
        newKeyInput.setVisible(false);
        selectionBox.setVisible(true);
        promptText.setText("Select Option: ");
    }

    /**
     * Creates and displays a filechooser, with file extensions restricted to txt files
     *
     * @param actionType String that indicates what the filechooser requires the user to do (encrypt, decrypt)
     * @return filepath for file to open
     */

    private File locateFilePath(String actionType) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Please select the file to " + actionType);
        FileChooser.ExtensionFilter txtFilter = new FileChooser.ExtensionFilter(".txt files (*.txt)", "*.txt");
        fc.getExtensionFilters().add(txtFilter);
        return fc.showOpenDialog(new Stage());
    }

    /**
     * Creates a new popout screen, with a text area to display desired text.
     *
     * @param textToPrint text to be placed into TextArea
     * @param stageName   name of the stage - indicates to the user what is being displayed
     */
    private void createPopout(String textToPrint, String stageName) {
        Stage popout = new Stage();
        popout.initModality(Modality.APPLICATION_MODAL);
        VBox popoutVBox = new VBox(20);
        popoutVBox.getChildren().add(new TextArea(textToPrint));
        Scene popoutScene = new Scene(popoutVBox, 300, 200);
        popout.setTitle(stageName);
        popout.setScene(popoutScene);
        popout.show();
    }

    /**
     * Creates a new SaveOperationController object, and passes it the value of the text resulting from the desired operation
     * (encryption, decryption, prepared plain text)
     *
     * @throws IOException if file cannot be loaded
     */
    private void createSaveDialogue() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SaveOperationPopup.fxml"));
        Parent root = loader.load();

        SaveOperationController saveOperationController = loader.getController();
        saveOperationController.transferText(resultText); //transfer the text from this object to the newly created SaveOperationController object

        //Create and display new stage
        Stage saveDialogue = new Stage();
        saveDialogue.setTitle("Save result");
        saveDialogue.setScene(new Scene(root, 300, 275));
        saveDialogue.show();
    }


    /**
     * Prints the prepared plain text to a new window, and prompts the user to save the result
     *
     * @throws IOException if file cannot be loaded
     */
    private void printPlainText() throws IOException {
        File filename = locateFilePath("display prepared plain text.");
        VigenereShiftCipher plainText = new VigenereShiftCipher(); //This could be any type of cipher object that has the preparePlainText method
        String result = plainText.preparePlainText(filename.toString()); //Load plain text from cipher object, and save it to result
        createSaveDialogue();
        createPopout(result, "Prepared Plain Text");
    }

    /**
     * Prompts the user to locate a txt file to encrypt, and if the selection is not null creates a CaesarShiftCipher object and
     * encrypts the text, using the caesarKeyFile filepath
     *
     * @throws IOException if file cannot be loaded
     */
    private void encryptCaesar() throws IOException {
        CaesarShiftCipher cCipher = new CaesarShiftCipher();
        File fileName = locateFilePath("encrypt");
        if (fileName != null) { //If user presses 'cancel' instead of making a selection
            resultText = cCipher.encrypt(fileName.toString(), CAESARKEYFILE);
            createSaveDialogue(); //Prompt user to save result
            createPopout(resultText, "Encrypted Caesar Result");
        }
    }

    /**
     * Prompts the user to locate a txt file to decrypt, and if the selection is not null creates a CaesarShiftCipher object and
     * decrypts the text, using the caesarKeyFile filepath
     *
     * @throws IOException if file cannot be loaded
     */
    private void decryptCaesar() throws IOException {
        CaesarShiftCipher cCipher = new CaesarShiftCipher();
        File fileName = locateFilePath("decrypt");
        if (fileName != null) { //If user presses 'cancel' instead of making a selection
            resultText = cCipher.decrypt(fileName.toString(), CAESARKEYFILE);
            createSaveDialogue(); //Prompt user to save result
            createPopout(resultText, "Decrypted Caesar Result");
        }
    }

    /**
     * Checks to see if the attempted input in the newKeyInput textbox is in the expected format (between 1-26) using a regex expression
     * Will not accept input if the key is not in the required format
     * Accepts the key if it fits the expected format, and changes the key in the key file location to the new key
     */
    private void changeCaesarKey() {
        if (newKeyInput.getText().matches("^(2[0-6]|1[0-9]|[1-9]$)")) { //If text is 1-26
            CaesarShiftCipher cCipher = new CaesarShiftCipher();
            cCipher.changeKey(CAESARKEYFILE, newKeyInput.getText()); //Change key to text in newKeyInput
            switchToDefaultScene(); //Switch back to the default app screen (hides text input, unhides comboBox, resets text prompt to "Select Option"
        } else {
            promptText.setText("Invalid Key: ");
        }
    }

    /**
     * Handles behaviour in the case that the radio menu item selected is Caesar Cipher
     *
     * @throws IOException if file cannot be loaded
     */
    private void handleCaesarInput() throws IOException {

        switch (selectionBox.getValue()) { //Get value in selection box
            case "Encrypt":
                encryptCaesar();
                break;
            case "Decrypt":
                decryptCaesar();
                break;
            case "Change Key":
                switchToKeyInputScene();
                selectionBox.setValue("cc awaitingInput"); //Set to flag not selectable by user, indicating we are awaiting input for a caesar cipher type key
                break;
            case "Display Key":
                CaesarShiftCipher cCipher = new CaesarShiftCipher();
                createPopout(cCipher.loadKey(CAESARKEYFILE), "Caesar Key");
                break;
            default:
                break;
        }
    }

    /**
     * Prompts the user to locate a txt file to encrypt, and if the selection is not null creates a VigenereShiftCipher object and
     * encrypts the text, using the vigenereKeyFile filepath
     *
     * @throws IOException if file cannot be loaded
     */
    private void encryptVigenere() throws IOException {
        VigenereShiftCipher vCipher = new VigenereShiftCipher();
        File fileName = locateFilePath("encrypt");
        if (fileName != null) {
            resultText = vCipher.encrypt(fileName.toString(), VIGENEREKEYFILE);
            createSaveDialogue();
            createPopout(resultText, "Encrypted Vigenere Result");
        }
    }

    /**
     * Prompts the user to locate a txt file to decrypt, and if the selection is not null creates a VigenereShiftCipher object and
     * decrypts the text, using the vigenereKeyFile filepath
     *
     * @throws IOException if file cannot be loaded
     */
    private void decryptVigenere() throws IOException {
        VigenereShiftCipher vCipher = new VigenereShiftCipher();
        File fileName = locateFilePath("encrypt");
        if (fileName != null) {
            resultText = vCipher.decrypt(fileName.toString(), VIGENEREKEYFILE);
            createSaveDialogue();
            createPopout(resultText, "Decrypted Vigenere Result");
        }
    }

    /**
     * Checks to see if the attempted input in the newKeyInput textbox is in the expected format (contains any alphabetic characters) using a regex expression
     * Will not accept input if the key is not in the required format
     * Accepts the key if it fits the expected format, and changes the key in the key file location to the new key
     */
    private void changeVigenereKey() {
        if (newKeyInput.getText().matches(".*[A-Za-z]+.*")) { //Any key that contains any alphabetic characters
            VigenereShiftCipher vc = new VigenereShiftCipher();
            vc.changeKey(VIGENEREKEYFILE, newKeyInput.getText()); //Change key to text in newKeyInput
            switchToDefaultScene(); //Switch back to the default app screen (hides text input, unhides comboBox, resets text prompt to "Select Option"
        } else {
            promptText.setText("Invalid Key: ");
        }
    }

    /**
     * Handles behaviour in the case that the radio menu item selected is Vigenere Cipher
     *
     * @throws IOException if file cannot be loaded
     */
    private void handleVignereInput() throws IOException {

        switch (selectionBox.getValue()) { //Get value in selection box
            case "Encrypt":
                encryptVigenere();
                break;
            case "Decrypt":
                decryptVigenere();
                break;
            case "Change Key":
                switchToKeyInputScene();
                selectionBox.setValue("vc awaitingInput"); //Set to flag not selectable by user, indicating we are awaiting input for a viegnere cipher type key
                break;
            case "Display Key":
                VigenereShiftCipher vc = new VigenereShiftCipher();
                createPopout(vc.loadKey(VIGENEREKEYFILE), "Vigenere Key");
                break;
            default:
                break;
        }
    }

    /**
     * Prompts the user to locate a txt file to encrypt, and if the selection is not null creates a KeyedCaesarCipher object and
     * encrypts the text, using the keyedCaesarKeyFile filepath
     *
     * @throws IOException if file cannot be loaded
     */
    private void encryptKeyedCaesar() throws IOException {
        KeyedCaesarCipher kcCipher = new KeyedCaesarCipher();
        File fileName = locateFilePath("encrypt");
        if (fileName != null) {
            resultText = kcCipher.encrypt(fileName.toString(), KEYEDCAESARKEYFILE);
            createSaveDialogue();
            createPopout(resultText, "Encrypted Keyed Caesar Result");
        }
    }

    /**
     * Prompts the user to locate a txt file to decrypt, and if the selection is not null creates a KeyedCaesarCipher object and
     * decrypts the text, using the keyedCaesarKeyFile filepath
     *
     * @throws IOException if file cannot be loaded
     */
    private void decryptKeyedCaesar() throws IOException {
        KeyedCaesarCipher kcCipher = new KeyedCaesarCipher();
        File fileName = locateFilePath("encrypt");
        if (fileName != null) {
            resultText = kcCipher.decrypt(fileName.toString(), KEYEDCAESARKEYFILE);
            createSaveDialogue();
            createPopout(resultText, "Decrypted Keyed Caesar Result");
        }
    }

    /**
     * Checks to see if the attempted input in the newKeyInput textbox is in the expected format (contains any alphabetic characters) using a regex expression
     * Will not accept input if the key is not in the required format
     * Accepts the key if it fits the expected format, and changes the key in the key file location to the new key
     */
    private void changeKeyedCaesarKey() {
        if (newKeyInput.getText().matches(".*[A-Za-z]+.*")) { //Any key that contains any alphabetic characters
            KeyedCaesarCipher kcCipher = new KeyedCaesarCipher();
            kcCipher.changeKey(KEYEDCAESARKEYFILE, newKeyInput.getText()); //Change key to text in newKeyInput
            switchToDefaultScene(); //Switch back to the default app screen (hides text input, unhides comboBox, resets text prompt to "Select Option"
        } else {
            promptText.setText("Invalid Key: ");
        }
    }

    /**
     * Handles behaviour in the case that the radio menu item selected is Keyed Caesar Cipher
     *
     * @throws IOException if file cannot be loaded
     */
    private void handleKeyedCaesarInput() throws IOException { //Get value in selection box
        switch (selectionBox.getValue()) {
            case "Encrypt":
                encryptKeyedCaesar();
                break;
            case "Decrypt":
                decryptKeyedCaesar();
                break;
            case "Change Key":
                switchToKeyInputScene();
                selectionBox.setValue("kc awaitingInput"); //Set to flag not selectable by user, indicating we are awaiting input for a keyed caesar cipher type key
                break;
            case "Display Key":
                KeyedCaesarCipher kcCipher = new KeyedCaesarCipher();
                createPopout(kcCipher.loadKey(KEYEDCAESARKEYFILE), "Keyed Caesar Key");
                break;
            default:
                break;
        }
    }

    /**
     * Closes the stage upon the exitButton element being pressed.
     */

    public void closeApp() {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
    }
}
