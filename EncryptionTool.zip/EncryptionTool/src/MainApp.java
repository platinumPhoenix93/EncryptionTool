import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * The encryption tool sysyem
 *
 * @author Courtney Mills
 * @version 1 (8th May 2020)
 */

public class MainApp extends Application {

    /**
     *Builds and populates a JavaFX GUI
     *
     * @param primaryStage container to build JavaFX GUI into
     * @throws IOException If unable to load FXML File
     */

    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/encryptiontool/GUI/EncryptionToolGUI.fxml")); //Load fxml file for the main GUI page
        primaryStage.setTitle("Encryption Tool");
        primaryStage.setScene(new Scene(root, 450, 200));
        primaryStage.setMinHeight(240);
        primaryStage.setMinWidth(470);
        primaryStage.setMaxHeight(240);
        primaryStage.setMaxWidth(470);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}